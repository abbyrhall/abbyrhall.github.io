# Chasing "The Aesthetic"

-Beautiful calligraphy, cute doodles, exquisite handwriting, perfectly straight, free-hand lines.

-Mason jars, flourishing succulents, fairy lights, polaroids.

-Empty deskspace, perfect cable management, two pens perfectly aligned in one corner, a book about productivity in the other.

I need them all. I covet these different aesthetics and yearn to claim this as my own. I want to simultaneously minimize any decoration or clutter on my desk, whilst dotting it with organizers filled to the brim with cute, pastel highlighters, a rainbow of pens, and a myriad of stickers, sticky notes, and stamps. These two cannot coexist simultaneously, yet I yearn for it.

Why? Secondly, when I inevitably fail to become these perfect recreations of "the aesthetic," what is there to learn from it? Let's make a list of "why," shall we?

1. Each aesthetic is cohesive. These things fit together; they work well with one another; they complement and add to the general beauty of the area.
2. The aesthetic is simplistic. I'm a sucker for the modest, simple vibe, with a few dashes of beauty, in one form or another. These simple ideas of "aesthetic," filled with organized, thought-out beauty, are an absolute dream. As a collective, it achieves simplicity and elegance.
3. Aesthetics are put-together. To have an aesthetic is to say, "I have a clear view of what I want, what I need, and how to get it. I plan well; I'm efficient; I'm organized."

I believe the last one is the most important. I see these people—on YouTube, on blogs, on Instagram—who show us a slice of their life. They present a moment in time where their desk is clear of clutter, the calligraphy is perfect, the fairy lights are on. Whatever it may be, they still present us with the best of themselves, as anyone would. I certainly try to. I want to be my best self; most people do. I want to appear put-together, efficient, organized. So, when I see this aesthetic bliss combined with tips about staying organized, I begin to associate these little snippets of life as the whole pie. In reality, they cut out the best piece, plate it, wipe away the leaking cherry juice that dribbled onto the plate, and then snapped a photo of the beautiful latticework moments before the pie sunk to the side.

The pie is still delicious and great, but the shared information only portrays a single, perfect moment in time. Yes, the slice of pie did look like that, but to say it always looks perfect is a lie. That is why, when I inevitably fail to create the ideal aesthetic, I feel bad. I am comparing messy, continuous life to a snapshot.

Over the years, I have worked with conflicting desires of design and decor intentions, and have cobbled together an "aesthetic." To me, it feels like a lie. To me, it is merely a hodge-podge of idea robbery and design theft.

-A bullet journal. Drawings of animals. Sticky notes with treble clefs stamped on the sides.

-A mason jar slowly being filled with spare change. Fairy lights ringing the corkboard. Mason jars stowing away my pens and markers in rainbow bliss.

-Metallic accents. A DIY tool board made on the corkboard of my desk, where I've used pins and binder clips to hang scissors, rulers, and other craft equipment—empty walls, very little atop my dresser and shelves.

My dad says my room is barren. My mom says it's cluttered.

I fail to have a cohesive aesthetic that can be put into a single category, like the ones presented on the internet. I don't have any cute succulents in little white boxes. I don't have exquisite cable management. I don't have phenomenal handwriting. I'm simply a conglomerate of what I love. To some, it may not be coherent and "*aesthetic."* To some, it may be dull and empty.

However, it is mine. I've created my own aesthetic. It is utilitarian, with dashes of beauty accentuated in a simple manner. Sometimes, my aesthetic is messy. Sometimes it's pristine. It's cohesive for me, and it works. I somehow manage to keep it reasonably organized, and I sometimes even open my curtains and turn on the fairy lights. The slice of life presented in this blog is even inaccurate to a degree. Occasionally, dirty clothing litters the floor of my room. Most often, the bed doesn't get made.

Everyone chooses what parts of their life they wish to thrive. If you flourish by laboring over calligraphy and perfect handwriting, great. If surrounding yourself with nothing enables you to create something, go for it. If cute, little plants make you smile and take a deep, relaxing breath, then get the plants. However, chasing after the perfect aesthetic never works. Find the hodge-podge of beauty and utility that works for you. Don't follow the fairy lights of aesthetic bliss into the swamp of perfection; you'll sink into overwhelming expectations. Build your own with what you love, while avoiding the rigidity of that slice of life taken before the crust sagged to the side.

Build your own aesthetic, and accept the perfection that rises from consistent, acceptable, normal imperfection.